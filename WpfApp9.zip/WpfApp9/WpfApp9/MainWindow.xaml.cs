﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp9;
public partial class MainWindow : Window
{
    public List<Contact> contacts { get; set; }

    public class Contact
    {
        public string? ContactName { get; set; }
        public string? ProfilePhoto { get; set; }
        public string? LastMessage { get; set; }
        public string? LastSent { get; set; }
    }
    public MainWindow()
    {
        InitializeComponent();
        contacts = new List<Contact>
    {
        new Contact
        {
            ContactName = "John Doe",
            ProfilePhoto = "john_profile.jpg",
            LastMessage = "Hello!",
            LastSent = "10:30 AM"
        },
        new Contact
        {
            ContactName = "Jane Smith",
            ProfilePhoto = "jane_profile.jpg",
            LastMessage = "Hi there!",
            LastSent = "Yesterday"
        },
    };
        DataContext = this;
    }
    private void ChatList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (ChatList.SelectedItem != null)
        {
            Contact selectedContact = (Contact)ChatList.SelectedItem;
            LoadChat(selectedContact);
        }
    }

    private void LoadChat(Contact contact)
    {
        messageContainer.Children.Clear();

        if (contact.ContactName == "John Doe")
        {

            AddChatMessage("Hi John!", true);
            AddChatMessage("Hello!", false);
            AddChatMessage("How are you?", true);
            AddChatMessage("I'm good, thanks!", false);
        }
        else if (contact.ContactName == "Jane Smith")
        {

            AddChatMessage("Hey Jane!", true);
            AddChatMessage("Hi there!", false);
            AddChatMessage("What's up?", true);
            AddChatMessage("Not much, just working.", false);
        }
    }


    private void Button_Click(object sender, RoutedEventArgs e)
    {
        string message = new TextRange(messageTextBox.Document.ContentStart, messageTextBox.Document.ContentEnd).Text;

        var b = AddChatMessage(message, true);
        messageTextBox.Document.Blocks.Clear();
        messageContainer.Height += b;

    }

    private dynamic AddChatMessage(string message, bool isYou)
    {
        TextBlock messageText = new TextBlock
        {
            Text = message,
            Background = isYou ? Brushes.LightBlue : Brushes.WhiteSmoke,
            Foreground = Brushes.Black,
            FontSize = 14,
            FontWeight = FontWeights.Bold,
            Width = double.NaN,
            MaxWidth = 200,
            Margin = isYou ? new Thickness(0, 5, 0, 0) : new Thickness(0, 0, 0, 5),
            TextWrapping = TextWrapping.Wrap
        };

        TextBlock timeText = new TextBlock
        {
            Text = DateTime.Now.ToString("HH:mm"),
            Foreground = Brushes.Gray,
            Margin = isYou ? new Thickness(0, 0, 0, 5) : new Thickness(0, 5, 0, 0),
            HorizontalAlignment = isYou ? HorizontalAlignment.Right : HorizontalAlignment.Left
        };

        StackPanel messageWithTime = new StackPanel
        {
            Orientation = Orientation.Vertical,
            Children = { messageText, timeText }
        };

        Border border = new Border
        {
            Background = isYou ? Brushes.LightBlue : Brushes.WhiteSmoke,
            CornerRadius = isYou ? new CornerRadius(10, 0, 10, 10) : new CornerRadius(0, 10, 10, 10),
            Padding = new Thickness(5),
            BorderThickness = new Thickness(1),
            BorderBrush = Brushes.Black,
            Margin = isYou ? new Thickness(150, 5, 5, 5) : new Thickness(5, 5, 150, 5),
            Width = double.NaN,
            HorizontalAlignment = isYou ? HorizontalAlignment.Right : HorizontalAlignment.Left,
            Child = messageWithTime
        };

        var a = border.Height;
        messageContainer.Children.Add(border);
        return a;
    }

    private void SearchTextBox_GotFocus(object sender, RoutedEventArgs e)
    {
        if (SearchTextBox.Text == "Search Contacts")
        {
            SearchTextBox.Foreground = Brushes.Black;
            SearchTextBox.Text = "";
        }
    }

    private void SearchTextBox_LostFocus(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(SearchTextBox.Text))
        {
            SearchTextBox.Foreground = Brushes.Gray;
            SearchTextBox.Text = "Search Contacts";
        }
    }
    private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
    {

        string searchText = SearchTextBox.Text.ToLower();
        if (contacts != null)
        {
            List<Contact> filteredContacts = contacts.Where(contact => contact.ContactName != null && contact.ContactName.ToLower().Contains(searchText)).ToList();

            ChatList.ItemsSource = filteredContacts;
        }
    }

}
